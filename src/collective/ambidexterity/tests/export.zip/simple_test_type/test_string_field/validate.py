# Validator script.
# Use this to set the validator for a Dexterity content-type field.
# This script will be executed in a RestrictedPython environment.
# local variables available to you:
#     context -- the folder in which the item is being added.
#     value -- the value to test for validity.
# If the validator script determines the value is invalid, it should do
# assign an error message to a variable named "error_message".
#
# If the value is valid, do not assign a value to error_message.
# The absence of an error message is taken to mean all is OK.

# error_message = u"This is an error message."
