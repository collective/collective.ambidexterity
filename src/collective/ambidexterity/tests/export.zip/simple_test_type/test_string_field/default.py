# Default script.
# Use this to set the default for a Dexterity content-type field.
# This script will be executed in a RestrictedPython environment.
# Local variables available to you:
#     context -- the folder in which the item is being added.
# Set your default by assigning it to "default".
# The value you set must match the field type.

default = None
