# Vocabulary script.
# Use this to set the default for a Dexterity content-type field.
# This script will be executed in a RestrictedPython environment.
# Local variables available to you:
#     context -- the folder in which the item is being added.
# Set your vocabulary by assigning it to "vocabulary".
# It should be a list of values or a list of (title, value) items.

vocabulary = []
